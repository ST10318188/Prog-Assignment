/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog.p1;

/**
 *
 * @author 27730
 */
import java.util.Scanner;

public class PROGP1 {
boolean checkUserName,checkPasswordComplexity,loginUser;// variables used to check username and password 
    static String password,username, registerUser,returnLoginStatus; // variables used through program
    static String usernameRegistration;
    static String passwordRegistration;
    
    
    
    public static void main(String[] args) {
   
     Scanner readUsername = new Scanner (System.in);// initialize scanner
     System.out.println("Please enter username");   // This section asks users to input a username
     
     usernameRegistration = readUsername.nextLine();
  
        if {
             (userName.contains("_") && userName.length() <= 5 )); // conditions needed for an acceptable username 
       System.out.println("Username successfully captured"); // output displayed to user
    }
       else {
               
       System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length"); // output displayed if username does not met conditions
       
        }
       
       Scanner readPassword = new Scanner (System.in); // initializes scanner
        System.out.println("Please enter password"); // asks user to input an acceptable password
     
     passwordRegistration = readPassword.nextLine();
       
      
 if {
  (password.length() <=8 && containsSpecial(password) && containsUppercase(password) && containsDigit(password)); // lists requirements needed for an acceptable password.
     System.out.println("Password successfully captured"); // output displayed to user after acceptable password is enetered.
 }
 else {
     
 }
     System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.”); "
             + 
             
     
 }
     
 
Scanner readUsernameRegistration = new Scanner (System.in); // initilizes scanner that will be used
 System.out.println("Please enter username"); // output that will be displayed to user requesting input data
     
     usernameRegistration = readUsernameRegistration.nextLine();
 
if {
 username.equals(usernameRegistration); // checks username meets criteria and is recognized
 System.out.println("Welcome <user first name> ,<user last name> it is great to see you again."); // output that will be displayed to user once successfully logged in
 
}


Scanner readPasswordRegistration = new Scanner (System.in);
 System.out.println("Please enter Password");
     
     passwordRegistration = readPasswordRegistration.nextLine();

 if {
         password.equals(passwordRegistration); //checks password meets criteria and is recognized
 System.out.println("“Welcome <user first name> ,<user last name> it is great to see you again.");
 
 }
 else {
     
 }
      System.out.println("Username or password incorrect, please try again"); // output display if password or username is not recognized.
     
     
 }

// Reference List 
//(no date) Google search. Google. Available at: https://www.google.com/search?q=how%2Bto%2Bimport%2Bscanner%2Bclass%2Bnetbeans&amp;oq=how%2Bto%2Bimport%2Bscanner%2Bclass%2Bnetbeans&amp;aqs=chrome..69i57j33i160j33i15i22i29i30.9988j0j7&amp;sourceid=chrome&amp;ie=UTF-8 (Accessed: April 28, 2023). 

//HadJower5HadJower5                    3588 bronze badges and christophetdchristophetd                    3 (1963) Replace scanner with bufferedreader, Stack Overflow. Available at: https://stackoverflow.com/questions/36551696/replace-scanner-with-bufferedreader (Accessed: April 28, 2023). 

//How to wait for user input in Javascript - keep the console open (node.js) (2023) YouTube. YouTube. Available at: https://www.youtube.com/watch?v=gCQtSbPGjZM&amp;list=PLrqwM2iFagujU_XxNawdmGcoqQWTSR5_m (Accessed: April 28, 2023). 

//UltimaniaUltimania                    10511 gold badge22 silver badges66 bronze badges et al. (1961) Java login program using a class, Stack Overflow. Available at: https://stackoverflow.com/questions/25599047/java-login-program-using-a-class (Accessed: April 28, 2023). 

//Wratislav, A. (2023) What is a RAR file and how do I open it?, What Is a RAR File and How Do I Open it? Avast. Available at: https://www.avast.com/c-how-to-open-rar-files#:~:text=Right%2Dclick%20the%20.rar%20formatted,unpacked%20files%2C%20then%20click%20Extract. (Accessed: April 28, 2023). 
 




